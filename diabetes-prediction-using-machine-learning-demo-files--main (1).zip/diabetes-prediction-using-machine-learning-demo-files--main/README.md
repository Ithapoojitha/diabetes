# diabetes-prediction-using-machine-learning-demo-files-
Files of demo of the project 

You can find the explanation of the complete project using this link and suggestions are welcome 
link : https://youtu.be/9FZV0JCA0MA

Thankyou 
I hope this helps you clear any doubts :)
